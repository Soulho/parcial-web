import header from './panel grande.png';
function NavBar() {
    return (
      <>
        <h1>Adopta un robot con Robot Lovers!</h1>
        <img src={header} alt="Robots Header" />
      </>
    );
   }
   
   export default NavBar;